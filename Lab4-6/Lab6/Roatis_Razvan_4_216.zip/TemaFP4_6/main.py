'''
    Porneste aplicatia de tranzactii
'''

from ui.console import run
from domain.tests import run_tests

run_tests()
run()

