'''
Created on 3 nov. 2017

@author: Rafa
'''
def meniu():
    
    print("add.Adauga o noua cheltuiala") 
    print("act. Actualizeaza o cheltuiala")
    print("cauta1.Tipareste cheltuielile mai mari decat o suma data") 
    print("cauta2.Tipareste toate cheltuielile efectuate inainte de o zi data si mai mici decat o suma")
    print("cauta3.Tipareste toate cheltuielile de un anumit tip")
    print("sterge1.Sterge cheltuielele pentru ziua data") 
    print("sterge2. sterge cheltuielile pentru un interval de timp")
    print("sterge3.sterge toate cheltuielille de un anumit tip") 
    print("rap1.suma totala pt un tip de cheltuiala")
    print("rap2.ziua cu suma maxima")    
    print("rap3.cheltuieli de o anumita suma")
    print("rap4.sortare dupa tip") 
    print("undo.undo")
    print("el.eliminacheltuielimimicidecat")
    print("exit.exit")